export const images = {
  hero: '/assets/hero_img.jpg',
  about: '/assets/about_us_image.jpg',
  logo: '/assets/bdrs_logo.jpg',
  OurFinger: '/assets/Our_finger.png',
  ByUncovering: '/assets/by_uncovering.png',
  ByRallying: '/assets/by_rallying.png',
  WhoWeAre: '/assets/whowe.png',
  whatWeDo: '/assets/whatWeDo.jpg',

    // Core Values images
  Integrity: '/assets/integrity.jpg',
  Ideas: '/assets/ideas.jpg',
  Relationships: '/assets/relationships.jpg',
  Results: '/assets/results.jpg',
  Improvement: '/assets/improvement.jpg',
};
