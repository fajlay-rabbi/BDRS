"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 7219:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CloseIcon)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9320);


function CloseIcon(props) {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        ...props,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
            viewBox: "0 0 24 24",
            focusable: "false",
            "aria-hidden": "true",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                fill: "currentColor",
                d: "M.439,21.44a1.5,1.5,0,0,0,2.122,2.121L11.823,14.3a.25.25,0,0,1,.354,0l9.262,9.263a1.5,1.5,0,1,0,2.122-2.121L14.3,12.177a.25.25,0,0,1,0-.354l9.263-9.262A1.5,1.5,0,0,0,21.439.44L12.177,9.7a.25.25,0,0,1-.354,0L2.561.44A1.5,1.5,0,0,0,.439,2.561L9.7,11.823a.25.25,0,0,1,0,.354Z"
            })
        })
    }));
};


/***/ }),

/***/ 2284:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Container = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
    componentId: "sc-110b5493-0"
})`
  position: relative;
  max-width: 130em;
  width: 100%;
  margin: 0 auto;
  padding: 0 2rem;
`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Container);


/***/ }),

/***/ 215:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _accessible_drawer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7672);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_accessible_drawer__WEBPACK_IMPORTED_MODULE_0__]);
_accessible_drawer__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_accessible_drawer__WEBPACK_IMPORTED_MODULE_0__);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2980:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Footer)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_icons_ci__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6607);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1301);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1780);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var components_Container__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2284);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_icons_ci__WEBPACK_IMPORTED_MODULE_1__, react_icons_fa__WEBPACK_IMPORTED_MODULE_2__, react_icons_fi__WEBPACK_IMPORTED_MODULE_3__]);
([react_icons_ci__WEBPACK_IMPORTED_MODULE_1__, react_icons_fa__WEBPACK_IMPORTED_MODULE_2__, react_icons_fi__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






function Footer() {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterWrapper, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_Container__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FooterTitle, {
                    children: "Get In Touch"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FooterGrid, {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            style: {
                                display: 'flex',
                                flexDirection: 'column',
                                gap: '20px'
                            },
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FooterItem, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Icon, {
                                            children: (0,react_icons_ci__WEBPACK_IMPORTED_MODULE_1__.CiGlobe)({})
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: "Website: www.bdrsbd.com"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FooterItem, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Icon, {
                                            children: (0,react_icons_fa__WEBPACK_IMPORTED_MODULE_2__.FaRegEnvelope)({})
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: "Email: info@bdrsbd.com"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FooterItem, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Icon, {
                                    children: (0,react_icons_ci__WEBPACK_IMPORTED_MODULE_1__.CiLocationOn)({})
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    style: {
                                        textAlign: 'justify'
                                    },
                                    children: "Address: Islam Chamber (2ND floor), 91, Agrabad C/A, Agrabad, Chattogram, Bangladesh & 50/A (Basement), Aziz Super Market, Shahbagh, Dhaka-1000"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FooterItem, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Icon, {
                                    children: (0,react_icons_fi__WEBPACK_IMPORTED_MODULE_3__.FiPhoneCall)({})
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: "Phone: +8802333310648"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    }));
};
const FooterWrapper = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
    componentId: "sc-18b9d583-0"
})`
  margin-top: -10px;
  padding-top: 10rem;
  padding-bottom: 4rem;
  background: rgb(var(--secondary));
  color: rgb(var(--textSecondary));
`;
const FooterTitle = styled_components__WEBPACK_IMPORTED_MODULE_4___default().h2.withConfig({
    componentId: "sc-18b9d583-1"
})`
  font-size: 24px;
  margin-bottom: 25px;
  font-weight: 600;
  text-align: center;
`;
const FooterGrid = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
    componentId: "sc-18b9d583-2"
})`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 40px;
  max-width: 1000px;
  margin: 0 auto;
  text-align: left;
`;
const FooterItem = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
    componentId: "sc-18b9d583-3"
})`
  display: flex;
  align-items: flex-start;
  gap: 12px;
  font-size: 15px;
  line-height: 1.5;
`;
const Icon = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
    componentId: "sc-18b9d583-4"
})`
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  background: #fff;
  width: 40px;
  height: 40px;
  border-radius: 10px;
  flex-shrink: 0;
`;

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2295:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ GlobalStyle)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const GlobalStyle = styled_components__WEBPACK_IMPORTED_MODULE_0__.createGlobalStyle`

.next-light-theme {
  --background: 251,251,253;
  --secondBackground: 255,255,255;
  --text: 10,18,30;
  --textSecondary: 255,255,255;
  --primary: 214,223,36;
  --secondary: 39,59,138;
  --tertiary: 231,241,251;
  --cardBackground: 255,255,255;
  --inputBackground: 255,255,255;
  --navbarBackground: 255,255,255;
  --modalBackground: 251,251,253;
  --errorColor: 207,34,46;
  --logoColor: #243A5A;
}

:root {
  --font: 'Poppins', sans-serif;
  
  --shadow-md: 0 2px 4px 0 rgb(12 0 46 / 4%);
  --shadow-lg: 0 10px 14px 0 rgb(12 0 46 / 6%);

  --z-sticky: 7777;
  --z-navbar: 8888;
  --z-drawer: 9999;
  --z-modal: 9999;
}

/* Box sizing rules */
*,
*::before,
*::after {
  box-sizing: border-box;
}

/* Remove default margin */
body,
h1,
h2,
h3,
h4,
p,
figure,
blockquote,
dl,
dd {
  margin: 0;
}


/* Remove list styles on ul, ol elements with a list role, which suggests default styling will be removed */
ul[role='list'],
ol[role='list'] {
  list-style: none;
}

/* Set core root defaults */
html:focus-within {
  scroll-behavior: smooth;
} 

html {
  -webkit-font-smoothing: antialiased;
  touch-action: manipulation;
  text-rendering: optimizelegibility;
  text-size-adjust: 100%;
  font-size: 62.5%;
  scroll-behavior: smooth;

  @media (max-width: 37.5em) {
    font-size: 50%;
  }

  @media (max-width: 48.0625em) {
    font-size: 55%;
  }

  @media (max-width: 56.25em) {
    font-size: 60%;
  }
}

/* Set core body defaults */
body {
  min-height: 100vh;
  text-rendering: optimizeSpeed;
  line-height: 1.5;
  font-family: var(--font);
  color: rgb(var(--text));
  background: rgb(var(--background));
  font-feature-settings: "kern";
  scroll-behavior: smooth;
}

svg {
  color: rgb(var(--text));
}

/* A elements that don't have a class get default styles */
a:not([class]) {
  text-decoration-skip-ink: auto;
}

/* Make images easier to work with */
img,
picture {
  max-width: 100%;
  display: block;
}

/* Inherit fonts for inputs and buttons */
input,
button,
textarea,
select {
  font: inherit;
}

/* Remove all animations, transitions and smooth scroll for people that prefer not to see them */
@media (prefers-reduced-motion: reduce) {
  html:focus-within {
   scroll-behavior: auto;
  }
  
  *,
  *::before,
  *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }

}`;


/***/ }),

/***/ 5886:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U": () => (/* binding */ HamburgerIcon)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Icon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9320);


function HamburgerIcon(props) {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        ...props,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
            stroke: "currentColor",
            fill: "currentColor",
            strokeWidth: "0",
            viewBox: "0 0 1024 1024",
            "aria-hidden": "true",
            focusable: "false",
            xmlns: "http://www.w3.org/2000/svg",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M904 160H120c-4.4 0-8 3.6-8 8v64c0 4.4 3.6 8 8 8h784c4.4 0 8-3.6 8-8v-64c0-4.4-3.6-8-8-8zm0 624H120c-4.4 0-8 3.6-8 8v64c0 4.4 3.6 8 8 8h784c4.4 0 8-3.6 8-8v-64c0-4.4-3.6-8-8-8zm0-312H120c-4.4 0-8 3.6-8 8v64c0 4.4 3.6 8 8 8h784c4.4 0 8-3.6 8-8v-64c0-4.4-3.6-8-8-8z"
            })
        })
    }));
}


/***/ }),

/***/ 9320:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Icon)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);



function Icon({ _ref , ...rest }) {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(IconWrapper, {
        type: "button",
        ...rest,
        ..._ref && {
            ref: _ref
        }
    }));
};
const IconWrapper = styled_components__WEBPACK_IMPORTED_MODULE_2___default().button.withConfig({
    componentId: "sc-4323f2a-0"
})`
  border: none;
  background-color: transparent;
  width: 4rem;
`;


/***/ }),

/***/ 5120:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Logo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);


function Logo() {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LogoWrapper, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
            src: "/assets/logo.png",
            alt: "logo",
            height: 80
        })
    }));
};
const LogoWrapper = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
    componentId: "sc-2267d7a8-0"
})`
  width: 150px;
`;


/***/ }),

/***/ 4276:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Navbar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var hooks_useScrollPosition__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(195);
/* harmony import */ var utils_media__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5563);
/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2284);
/* harmony import */ var _Drawer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(215);
/* harmony import */ var _HamburgerIcon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5886);
/* harmony import */ var _Logo__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5120);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Drawer__WEBPACK_IMPORTED_MODULE_8__]);
_Drawer__WEBPACK_IMPORTED_MODULE_8__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];












'use client';
function Navbar() {
    var ref2, ref1;
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { 0: activeNav , 1: setActiveNav  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const { 0: activeNavContent , 1: setActiveNavContent  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const { toggle  } = _Drawer__WEBPACK_IMPORTED_MODULE_8__/* ["default"].useDrawer */ .Z.useDrawer();
    const { 0: scrollingDirection , 1: setScrollingDirection  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)('none');
    const { 0: isHoveringNav , 1: setIsHoveringNav  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    let lastScrollY = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)(0);
    const lastRoute = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)('');
    const stepSize = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)(50);
    (0,hooks_useScrollPosition__WEBPACK_IMPORTED_MODULE_5__/* .useScrollPosition */ .R)(scrollPositionCallback, [
        router.asPath
    ], undefined, undefined, 50);
    function scrollPositionCallback({ currPos  }) {
        const routerPath = router.asPath;
        const hasRouteChanged = routerPath !== lastRoute.current;
        if (hasRouteChanged) {
            lastRoute.current = routerPath;
            setScrollingDirection('none');
            return;
        }
        const currentScrollY = currPos.y;
        const isScrollingUp = currentScrollY > lastScrollY.current;
        const scrollDifference = Math.abs(lastScrollY.current - currentScrollY);
        const hasScrolledWholeStep = scrollDifference >= stepSize.current;
        const isInNonCollapsibleArea = lastScrollY.current > -50;
        if (isInNonCollapsibleArea) {
            setScrollingDirection('none');
            lastScrollY.current = currentScrollY;
            return;
        }
        if (!hasScrolledWholeStep) {
            lastScrollY.current = currentScrollY;
            return;
        }
        setScrollingDirection(isScrollingUp ? 'up' : 'down');
        lastScrollY.current = currentScrollY;
    }
    // Keep navbar visible unless scrolling down AND not hovering
    const isNavbarHidden = scrollingDirection === 'down' && !isHoveringNav;
    const isTransparent = scrollingDirection === 'none';
    // Default select the first sidebar item when a top-level nav is hovered
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        var ref;
        if (activeNav === null || activeNav === void 0 ? void 0 : (ref = activeNav.children) === null || ref === void 0 ? void 0 : ref.length) {
            // @ts-ignore – structure matches MenuItem shape
            setActiveNavContent(activeNav.children[0]);
        } else {
            setActiveNavContent(undefined);
        }
    }, [
        activeNav
    ]);
    const itemHoverHandler = (item)=>{
        setActiveNavContent(item);
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NavbarContainer, {
        hidden: isNavbarHidden,
        transparent: isTransparent,
        onMouseEnter: ()=>setIsHoveringNav(true)
        ,
        onMouseLeave: ()=>{
            setIsHoveringNav(false);
            setActiveNav(undefined);
            setActiveNavContent(undefined);
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Content, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                    href: "/",
                    passHref: true,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LogoWrapper, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Logo__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {})
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(NavItemList, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                            href: "/",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                style: {
                                    textDecoration: 'none',
                                    color: '#2d2d2d'
                                },
                                children: "Home"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                            href: "#whoWeAre",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                style: {
                                    textDecoration: 'none',
                                    color: '#2d2d2d'
                                },
                                children: "Who We Are"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                            href: "#ourVision",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                style: {
                                    textDecoration: 'none',
                                    color: '#2d2d2d'
                                },
                                children: "Our Vision"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                            href: "#ourMission",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                style: {
                                    textDecoration: 'none',
                                    color: '#2d2d2d'
                                },
                                children: "Our Mission"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                            href: "#ourCoreValues",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                style: {
                                    textDecoration: 'none',
                                    color: '#2d2d2d'
                                },
                                children: "Our Core Values"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                            href: "#whatWeDo",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                style: {
                                    textDecoration: 'none',
                                    color: '#2d2d2d'
                                },
                                children: "What We Do"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                            href: "#ourClients",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                style: {
                                    textDecoration: 'none',
                                    color: '#2d2d2d'
                                },
                                children: "Our Clients"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(HamburgerMenuWrapper, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_HamburgerIcon__WEBPACK_IMPORTED_MODULE_9__/* .HamburgerIcon */ .U, {
                        "aria-label": "Toggle menu",
                        onClick: toggle
                    })
                }),
                activeNav && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(MegaMenuWrapper, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MegaMenuSidebar, {
                            children: activeNav === null || activeNav === void 0 ? void 0 : (ref2 = activeNav.children) === null || ref2 === void 0 ? void 0 : ref2.map((item)=>{
                                return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SidebarMenuItem, {
                                    active: (item === null || item === void 0 ? void 0 : item.title) === (activeNavContent === null || activeNavContent === void 0 ? void 0 : activeNavContent.title),
                                    onMouseEnter: ()=>itemHoverHandler(item)
                                    ,
                                    children: item === null || item === void 0 ? void 0 : item.title
                                }, item === null || item === void 0 ? void 0 : item.title));
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MegaMenuContent, {
                            children: activeNavContent === null || activeNavContent === void 0 ? void 0 : (ref1 = activeNavContent.children) === null || ref1 === void 0 ? void 0 : ref1.map((item)=>{
                                var ref;
                                return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MenuItemTitle, {
                                            children: item === null || item === void 0 ? void 0 : item.title
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MenuItemLinkDiv, {
                                            children: item === null || item === void 0 ? void 0 : (ref = item.children) === null || ref === void 0 ? void 0 : ref.map((child, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MenuItemLink, {
                                                    href: "#",
                                                    children: child
                                                }, index)
                                            )
                                        })
                                    ]
                                }, item === null || item === void 0 ? void 0 : item.title));
                            })
                        })
                    ]
                })
            ]
        })
    }));
};
function NavItem({ item , setActiveNav  }) {
    const handleMegaMenuData = ()=>{
        setActiveNav(item);
    };
    return(/*#__PURE__*/ _jsx(NavItemWrapper, {
        onMouseEnter: handleMegaMenuData,
        children: /*#__PURE__*/ _jsxs("a", {
            href: "#",
            children: [
                item === null || item === void 0 ? void 0 : item.title,
                " +"
            ]
        })
    }));
}
const NavItemList = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
    componentId: "sc-4e081f20-0"
})`
  display: flex;
  item-align: center;
  gap: 4rem;
  font-size: 1.4rem;
  font-weight: 600;
  text-decoration: none;
  list-style: none;

  ${(0,utils_media__WEBPACK_IMPORTED_MODULE_6__/* .media */ .B)('<desktop')} {
    display: none;
  }
`;
const HamburgerMenuWrapper = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
    componentId: "sc-4e081f20-1"
})`
  ${(0,utils_media__WEBPACK_IMPORTED_MODULE_6__/* .media */ .B)('>=desktop')} {
    display: none;
  }
`;
const LogoWrapper = styled_components__WEBPACK_IMPORTED_MODULE_4___default().a.withConfig({
    componentId: "sc-4e081f20-2"
})`
  display: flex;
  margin-right: auto;
  text-decoration: none;

  color: rgb(var(--logoColor));
`;
const NavItemWrapper = styled_components__WEBPACK_IMPORTED_MODULE_4___default().li.withConfig({
    componentId: "sc-4e081f20-3"
})`
  background-color: ${(p)=>p.outlined ? 'rgb(var(--primary))' : 'transparent'
};
  border-radius: 0.5rem;
  font-size: 1.3rem;
  text-transform: uppercase;
  line-height: 2;

  &:hover {
    background-color: ${(p)=>p.outlined ? 'rgb(var(--primary), 0.8)' : 'transparent'
};
    transition: background-color 0.2s;
  }

  a {
    display: flex;
    color: ${(p)=>p.outlined ? 'rgb(var(--textSecondary))' : 'rgb(var(--text), 0.75)'
};
    letter-spacing: 0.025em;
    text-decoration: none;
    padding: 0.75rem 1.5rem;
    font-weight: 700;
  }

  &:not(:last-child) {
    margin-right: 2rem;
  }
`;
const NavbarContainer = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
    componentId: "sc-4e081f20-4"
})`
  display: flex;
  position: sticky;
  top: 0;
  padding: 1.5rem 0;
  width: 100%;
  height: 8rem;
  z-index: var(--z-navbar);

  background-color: rgb(var(--navbarBackground));
  box-shadow: 0 1px 2px 0 rgb(0 0 0 / 5%);
  visibility: ${(p)=>p.hidden ? 'hidden' : 'visible'
};
  transform: ${(p)=>p.hidden ? `translateY(-8rem) translateZ(0) scale(1)` : 'translateY(0) translateZ(0) scale(1)'
};

  transition-property: transform, visibility, height, box-shadow, background-color;
  transition-duration: 0.15s;
  transition-timing-function: ease-in-out;
`;
const Content = styled_components__WEBPACK_IMPORTED_MODULE_4___default()(_Container__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z).withConfig({
    componentId: "sc-4e081f20-5"
})`
  position: relative;
  display: flex;
  justify-content: flex-end;
  align-items: center;
`;
const MegaMenuWrapper = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
    componentId: "sc-4e081f20-6"
})`
  display: flex;
  align-items: center; /* fixed typo */
  position: absolute;
  width: 90%;
  height: 400px;
  top: 65px;
  z-index: 50;
  border-radius: 5px;
  overflow: hidden;
  border: 1px solid #f1f1f1;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
`;
const MegaMenuSidebar = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
    componentId: "sc-4e081f20-7"
})`
  padding: 5px;
  height: 100%;
  width: 40%;
  background: #1b1f66;
`;
const MegaMenuContent = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
    componentId: "sc-4e081f20-8"
})`
  padding: 15px;
  height: 100%;
  width: 60%; /* match 40% sidebar to avoid overflow */
  background: #fff;
  overflow-y: auto;
`;
const SidebarMenuItem = styled_components__WEBPACK_IMPORTED_MODULE_4___default().p.withConfig({
    componentId: "sc-4e081f20-9"
})`
  font-size: 16px;
  color: ${({ active  })=>active ? '#1b1f66' : '#fff'
};
  background-color: ${({ active  })=>active ? '#fff' : 'transparent'
};
  border-radius: 2px;
  cursor: pointer;
  padding: 10px;
  transition: all 0.2s ease-in-out;

  &:hover {
    color: #1b1f66;
    background-color: #fff;
  }
`;
const MenuItemTitle = styled_components__WEBPACK_IMPORTED_MODULE_4___default().p.withConfig({
    componentId: "sc-4e081f20-10"
})`
  font-size: 14px;
  margin-bottom: 15px;
  font-weight: 600;
  cursor: pointer;
  color: #2d2d2d;
`;
const MenuItemLinkDiv = styled_components__WEBPACK_IMPORTED_MODULE_4___default().div.withConfig({
    componentId: "sc-4e081f20-11"
})`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  place-items: start; /* left/start alignment */
  justify-items: start;
  gap: 1rem;
  margin-left: 15px;
`;
const MenuItemLink = styled_components__WEBPACK_IMPORTED_MODULE_4___default().a.withConfig({
    componentId: "sc-4e081f20-12"
})`
  font-size: 14px;
  padding-right: 40px;
  cursor: pointer;
  color: #2d2d2d;
  text-decoration: none;
  transition: color 0.3s ease;

  &:hover {
    color: #c4ce13ff;
    font-weight: 500;
  }
`;

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6236:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ NavigationDrawer)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _CloseIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7219);
/* harmony import */ var _Drawer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(215);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Drawer__WEBPACK_IMPORTED_MODULE_5__]);
_Drawer__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






function NavigationDrawer({ children , items  }) {
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Drawer__WEBPACK_IMPORTED_MODULE_5__/* ["default"].Drawer */ .Z.Drawer, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Wrapper, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Drawer__WEBPACK_IMPORTED_MODULE_5__/* ["default"].Target */ .Z.Target, {
                    openClass: "drawer-opened",
                    closedClass: "drawer-closed",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "my-drawer",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "my-drawer-container",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(DrawerCloseButton, {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NavItemsList, {
                                    items: items
                                })
                            ]
                        })
                    })
                })
            }),
            children
        ]
    }));
};
function NavItemsList({ items  }) {
    const { close  } = _Drawer__WEBPACK_IMPORTED_MODULE_5__/* ["default"].useDrawer */ .Z.useDrawer();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        function handleRouteChangeComplete() {
            close();
        }
        router.events.on('routeChangeComplete', handleRouteChangeComplete);
        return ()=>router.events.off('routeChangeComplete', handleRouteChangeComplete)
        ;
    }, [
        close,
        router
    ]);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
        children: items.map((singleItem, idx)=>{
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NavItem, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    href: `#${singleItem === null || singleItem === void 0 ? void 0 : singleItem.href}`,
                    children: singleItem.title
                })
            }, idx));
        })
    }));
}
function DrawerCloseButton() {
    const ref = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
    const a11yProps = _Drawer__WEBPACK_IMPORTED_MODULE_5__/* ["default"].useA11yCloseButton */ .Z.useA11yCloseButton(ref);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CloseIcon__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        className: "close-icon",
        _ref: ref,
        ...a11yProps
    }));
}
const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_3___default().div.withConfig({
    componentId: "sc-2f0f9d02-0"
})`
  .my-drawer {
    width: 100%;
    height: 100%;
    z-index: var(--z-drawer);
    background: rgb(var(--background));
    transition: margin-left 0.3s cubic-bezier(0.82, 0.085, 0.395, 0.895);
    overflow: hidden;
  }

  .my-drawer-container {
    position: relative;
    height: 100%;
    margin: auto;
    max-width: 70rem;
    padding: 0 1.2rem;
  }

  .close-icon {
    position: absolute;
    right: 2rem;
    top: 2rem;
  }

  .drawer-closed {
    margin-left: -100%;
  }

  .drawer-opened {
    margin-left: 0;
  }

  ul {
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: 0;
    margin: 0;
    list-style: none;

    & > *:not(:last-child) {
      margin-bottom: 3rem;
    }
  }
`;
const NavItem = styled_components__WEBPACK_IMPORTED_MODULE_3___default().li.withConfig({
    componentId: "sc-2f0f9d02-1"
})`
  a {
    font-size: 3rem;
    text-transform: uppercase;
    display: block;
    color: currentColor;
    text-decoration: none;
    border-radius: 0.5rem;
    padding: 0.5rem 1rem;
    text-align: center;
  }
`;

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 195:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "R": () => (/* binding */ useScrollPosition)
});

;// CONCATENATED MODULE: external "@n8tb1t/use-scroll-position"
const use_scroll_position_namespaceObject = require("@n8tb1t/use-scroll-position");
;// CONCATENATED MODULE: ./hooks/useScrollPosition.ts

function useScrollPosition(effect, deps, element, useWindow, wait, boundingElement) {
    return (0,use_scroll_position_namespaceObject.useScrollPosition)(effect, deps, element, useWindow, wait, boundingElement);
}


/***/ }),

/***/ 5656:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var nextjs_color_mode__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9918);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_Footer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2980);
/* harmony import */ var components_GlobalStyles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2295);
/* harmony import */ var components_Navbar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4276);
/* harmony import */ var components_NavigationDrawer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6236);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_Footer__WEBPACK_IMPORTED_MODULE_4__, components_Navbar__WEBPACK_IMPORTED_MODULE_6__, components_NavigationDrawer__WEBPACK_IMPORTED_MODULE_7__]);
([components_Footer__WEBPACK_IMPORTED_MODULE_4__, components_Navbar__WEBPACK_IMPORTED_MODULE_6__, components_NavigationDrawer__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const navItems = [
    {
        title: 'Insights',
        href: '#'
    },
    {
        title: 'Industries',
        href: '#'
    },
    {
        title: 'Capabilities',
        href: '#'
    },
    {
        title: 'Leadership',
        href: '#'
    },
    {
        title: 'About',
        href: '#'
    },
    {
        title: 'Careers',
        href: '#'
    }, 
];
function MyApp({ Component , pageProps  }) {
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "preconnect",
                        href: "https://fonts.googleapis.com"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "preconnect",
                        href: "https://fonts.gstatic.com",
                        crossOrigin: ""
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(nextjs_color_mode__WEBPACK_IMPORTED_MODULE_2__/* .ColorModeScript */ .ZQ, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_GlobalStyles__WEBPACK_IMPORTED_MODULE_5__/* .GlobalStyle */ .Z, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_NavigationDrawer__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                items: navItems,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Navbar__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                        ...pageProps
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Footer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                ]
            })
        ]
    }));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5563:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "B": () => (/* binding */ media)
});

;// CONCATENATED MODULE: external "css-in-js-media"
const external_css_in_js_media_namespaceObject = require("css-in-js-media");
var external_css_in_js_media_default = /*#__PURE__*/__webpack_require__.n(external_css_in_js_media_namespaceObject);
;// CONCATENATED MODULE: ./utils/media.ts

const media = (external_css_in_js_media_default());


/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 7518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 7672:
/***/ ((module) => {

module.exports = import("@accessible/drawer");;

/***/ }),

/***/ 6607:
/***/ ((module) => {

module.exports = import("react-icons/ci");;

/***/ }),

/***/ 1301:
/***/ ((module) => {

module.exports = import("react-icons/fa");;

/***/ }),

/***/ 1780:
/***/ ((module) => {

module.exports = import("react-icons/fi");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [190,676,907], () => (__webpack_exec__(5656)));
module.exports = __webpack_exports__;

})();