import * as OriginalDrawer from '@accessible/drawer'

export default OriginalDrawer
