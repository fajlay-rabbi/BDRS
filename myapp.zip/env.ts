export const EnvVars = {
  SITE_NAME: 'BDRS',
  OG_IMAGES_URL: 'https://next-saas-starter-ashy.vercel.app/og-images/',
  URL: 'https://next-saas-starter-ashy.vercel.app/',
};
