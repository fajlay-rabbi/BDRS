import useResizeObserver from 'use-resize-observer';

export { useResizeObserver };
