import { useClipboard } from 'use-clipboard-copy';

export { useClipboard };
